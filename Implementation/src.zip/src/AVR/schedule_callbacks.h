/*
 * schedule_callbacks.h
 *
 *  Created on: Aug 10, 2015
 *      Author: 10014232
 */

#ifndef SCHEDULE_CALLBACKS_H_
#define SCHEDULE_CALLBACKS_H_

void schedule_callback_Mailbox0( void );
void schedule_callback_Mailbox1( void );
void schedule_callback_Mailbox2( void );
void schedule_callback_Mailbox3( void );
void schedule_callback_Mailbox4( void );
void schedule_callback_Mailbox5( void );
void schedule_callback_Mailbox6( void );
void schedule_callback_Mailbox7( void );
void schedule_callback_Mailbox8( void );
void schedule_callback_Mailbox9( void );
void schedule_callback_Mailbox10( void );
void schedule_callback_Mailbox11( void );
void schedule_callback_Mailbox12( void );
void schedule_callback_Mailbox13( void );
void schedule_callback_Mailbox14( void );

void timeout_callback_Mailbox0( void );
void timeout_callback_Mailbox1( void );
void timeout_callback_Mailbox2( void );
void timeout_callback_Mailbox3( void );
void timeout_callback_Mailbox4( void );
void timeout_callback_Mailbox5( void );
void timeout_callback_Mailbox6( void );
void timeout_callback_Mailbox7( void );
void timeout_callback_Mailbox8( void );
void timeout_callback_Mailbox9( void );
void timeout_callback_Mailbox10( void );
void timeout_callback_Mailbox11( void );
void timeout_callback_Mailbox12( void );
void timeout_callback_Mailbox13( void );
void timeout_callback_Mailbox14( void );

#endif /* SCHEDULE_CALLBACKS_H_ */
