Qt-custom-gauge-widget
======================
Qt gauge custom widget for data visualization.

For mor information please visit http://pytricity.com/qt-circular-gauges/ 

This is a release for testing, the code needs more work on it, as I am willing to add more improvements.
