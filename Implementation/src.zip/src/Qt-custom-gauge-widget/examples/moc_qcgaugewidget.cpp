/****************************************************************************
** Meta object code from reading C++ file 'qcgaugewidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../source/qcgaugewidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qcgaugewidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_QcGaugeWidget_t {
    QByteArrayData data[1];
    char stringdata0[14];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcGaugeWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcGaugeWidget_t qt_meta_stringdata_QcGaugeWidget = {
    {
QT_MOC_LITERAL(0, 0, 13) // "QcGaugeWidget"

    },
    "QcGaugeWidget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcGaugeWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcGaugeWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcGaugeWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_QcGaugeWidget.data,
      qt_meta_data_QcGaugeWidget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcGaugeWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcGaugeWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcGaugeWidget.stringdata0))
        return static_cast<void*>(const_cast< QcGaugeWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int QcGaugeWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcItem_t {
    QByteArrayData data[1];
    char stringdata0[7];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcItem_t qt_meta_stringdata_QcItem = {
    {
QT_MOC_LITERAL(0, 0, 6) // "QcItem"

    },
    "QcItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcItem::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QcItem.data,
      qt_meta_data_QcItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcItem.stringdata0))
        return static_cast<void*>(const_cast< QcItem*>(this));
    return QObject::qt_metacast(_clname);
}

int QcItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcScaleItem_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcScaleItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcScaleItem_t qt_meta_stringdata_QcScaleItem = {
    {
QT_MOC_LITERAL(0, 0, 11) // "QcScaleItem"

    },
    "QcScaleItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcScaleItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcScaleItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcScaleItem::staticMetaObject = {
    { &QcItem::staticMetaObject, qt_meta_stringdata_QcScaleItem.data,
      qt_meta_data_QcScaleItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcScaleItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcScaleItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcScaleItem.stringdata0))
        return static_cast<void*>(const_cast< QcScaleItem*>(this));
    return QcItem::qt_metacast(_clname);
}

int QcScaleItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QcItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcBackgroundItem_t {
    QByteArrayData data[1];
    char stringdata0[17];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcBackgroundItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcBackgroundItem_t qt_meta_stringdata_QcBackgroundItem = {
    {
QT_MOC_LITERAL(0, 0, 16) // "QcBackgroundItem"

    },
    "QcBackgroundItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcBackgroundItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcBackgroundItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcBackgroundItem::staticMetaObject = {
    { &QcItem::staticMetaObject, qt_meta_stringdata_QcBackgroundItem.data,
      qt_meta_data_QcBackgroundItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcBackgroundItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcBackgroundItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcBackgroundItem.stringdata0))
        return static_cast<void*>(const_cast< QcBackgroundItem*>(this));
    return QcItem::qt_metacast(_clname);
}

int QcBackgroundItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QcItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcGlassItem_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcGlassItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcGlassItem_t qt_meta_stringdata_QcGlassItem = {
    {
QT_MOC_LITERAL(0, 0, 11) // "QcGlassItem"

    },
    "QcGlassItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcGlassItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcGlassItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcGlassItem::staticMetaObject = {
    { &QcItem::staticMetaObject, qt_meta_stringdata_QcGlassItem.data,
      qt_meta_data_QcGlassItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcGlassItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcGlassItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcGlassItem.stringdata0))
        return static_cast<void*>(const_cast< QcGlassItem*>(this));
    return QcItem::qt_metacast(_clname);
}

int QcGlassItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QcItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcLabelItem_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcLabelItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcLabelItem_t qt_meta_stringdata_QcLabelItem = {
    {
QT_MOC_LITERAL(0, 0, 11) // "QcLabelItem"

    },
    "QcLabelItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcLabelItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcLabelItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcLabelItem::staticMetaObject = {
    { &QcItem::staticMetaObject, qt_meta_stringdata_QcLabelItem.data,
      qt_meta_data_QcLabelItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcLabelItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcLabelItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcLabelItem.stringdata0))
        return static_cast<void*>(const_cast< QcLabelItem*>(this));
    return QcItem::qt_metacast(_clname);
}

int QcLabelItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QcItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcArcItem_t {
    QByteArrayData data[1];
    char stringdata0[10];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcArcItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcArcItem_t qt_meta_stringdata_QcArcItem = {
    {
QT_MOC_LITERAL(0, 0, 9) // "QcArcItem"

    },
    "QcArcItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcArcItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcArcItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcArcItem::staticMetaObject = {
    { &QcScaleItem::staticMetaObject, qt_meta_stringdata_QcArcItem.data,
      qt_meta_data_QcArcItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcArcItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcArcItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcArcItem.stringdata0))
        return static_cast<void*>(const_cast< QcArcItem*>(this));
    return QcScaleItem::qt_metacast(_clname);
}

int QcArcItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QcScaleItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcColorBand_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcColorBand_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcColorBand_t qt_meta_stringdata_QcColorBand = {
    {
QT_MOC_LITERAL(0, 0, 11) // "QcColorBand"

    },
    "QcColorBand"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcColorBand[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcColorBand::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcColorBand::staticMetaObject = {
    { &QcScaleItem::staticMetaObject, qt_meta_stringdata_QcColorBand.data,
      qt_meta_data_QcColorBand,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcColorBand::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcColorBand::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcColorBand.stringdata0))
        return static_cast<void*>(const_cast< QcColorBand*>(this));
    return QcScaleItem::qt_metacast(_clname);
}

int QcColorBand::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QcScaleItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcDegreesItem_t {
    QByteArrayData data[1];
    char stringdata0[14];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcDegreesItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcDegreesItem_t qt_meta_stringdata_QcDegreesItem = {
    {
QT_MOC_LITERAL(0, 0, 13) // "QcDegreesItem"

    },
    "QcDegreesItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcDegreesItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcDegreesItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcDegreesItem::staticMetaObject = {
    { &QcScaleItem::staticMetaObject, qt_meta_stringdata_QcDegreesItem.data,
      qt_meta_data_QcDegreesItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcDegreesItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcDegreesItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcDegreesItem.stringdata0))
        return static_cast<void*>(const_cast< QcDegreesItem*>(this));
    return QcScaleItem::qt_metacast(_clname);
}

int QcDegreesItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QcScaleItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcNeedleItem_t {
    QByteArrayData data[1];
    char stringdata0[13];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcNeedleItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcNeedleItem_t qt_meta_stringdata_QcNeedleItem = {
    {
QT_MOC_LITERAL(0, 0, 12) // "QcNeedleItem"

    },
    "QcNeedleItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcNeedleItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcNeedleItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcNeedleItem::staticMetaObject = {
    { &QcScaleItem::staticMetaObject, qt_meta_stringdata_QcNeedleItem.data,
      qt_meta_data_QcNeedleItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcNeedleItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcNeedleItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcNeedleItem.stringdata0))
        return static_cast<void*>(const_cast< QcNeedleItem*>(this));
    return QcScaleItem::qt_metacast(_clname);
}

int QcNeedleItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QcScaleItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcValuesItem_t {
    QByteArrayData data[1];
    char stringdata0[13];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcValuesItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcValuesItem_t qt_meta_stringdata_QcValuesItem = {
    {
QT_MOC_LITERAL(0, 0, 12) // "QcValuesItem"

    },
    "QcValuesItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcValuesItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcValuesItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcValuesItem::staticMetaObject = {
    { &QcScaleItem::staticMetaObject, qt_meta_stringdata_QcValuesItem.data,
      qt_meta_data_QcValuesItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcValuesItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcValuesItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcValuesItem.stringdata0))
        return static_cast<void*>(const_cast< QcValuesItem*>(this));
    return QcScaleItem::qt_metacast(_clname);
}

int QcValuesItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QcScaleItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QcAttitudeMeter_t {
    QByteArrayData data[1];
    char stringdata0[16];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QcAttitudeMeter_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QcAttitudeMeter_t qt_meta_stringdata_QcAttitudeMeter = {
    {
QT_MOC_LITERAL(0, 0, 15) // "QcAttitudeMeter"

    },
    "QcAttitudeMeter"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QcAttitudeMeter[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QcAttitudeMeter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QcAttitudeMeter::staticMetaObject = {
    { &QcItem::staticMetaObject, qt_meta_stringdata_QcAttitudeMeter.data,
      qt_meta_data_QcAttitudeMeter,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QcAttitudeMeter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QcAttitudeMeter::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QcAttitudeMeter.stringdata0))
        return static_cast<void*>(const_cast< QcAttitudeMeter*>(this));
    return QcItem::qt_metacast(_clname);
}

int QcAttitudeMeter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QcItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE
