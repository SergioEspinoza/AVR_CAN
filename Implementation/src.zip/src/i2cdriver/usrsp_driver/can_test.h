

// fake read
int fake_read( int fd , char* bytes , int num);
int fake_write( int fd,  char* bytes, int num );

