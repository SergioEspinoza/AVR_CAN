#ifndef SOCKETTEST_H
#define SOCKETTEST_H

#include <QObject>
#include <QDebug>
#include <QTcpSocket>
#include <QLocalSocket>
#include <QAbstractSocket>
#include <raspi_ipc_defs.h>

class ClientConnection : public QObject
{
    Q_OBJECT

public:
    explicit ClientConnection(QObject *parent = 0);
    void connectToServer(void );
    QLocalSocket::LocalSocketState state( void );
    
signals:
    void newData( int16_t value, int8_t unitSel );
public slots:
    void connected();
    void disconnected();
    void bytesWritten(qint64 bytes);
    void readyRead();

private:
    static QString serverName;
    QLocalSocket *socket;

};

#endif // SOCKETTEST_H
